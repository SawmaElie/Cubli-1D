#include <stdint.h>
#include "stm32f3xx_hal.h"
#include <stdint.h>
#include <math.h>

void ReactionWheelPWM(void);
extern float loopOnce;
extern TIM_HandleTypeDef htim1;
